#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <iomanip>

typedef long long ll;

using namespace std;

int carpas;

//bool full(vector<bool> &v)
//{
	//for (int i=0; i<v.size(); ++i)
		//if (!v[i]) return false;
	//return true;
//}

void bt(vector<ll> &p, vector<bool> &vistos, int c, int alturaant, int cant){
	
	vistos[c] = true;
	if (cant == p.size()-2){
	//if (full(vistos)){
		//cerr<<"carpas++\n";
		carpas++;
		return;
	}
	
	int ant = -1;
	for (int i=0; i<p.size(); ++i){
		if (!vistos[i]){
			if (p[c] - alturaant > p[i] - p[c]){
				if (p[i] != ant){
					ant = p[i];
					vistos[i] = true;
					bt(p, vistos, i, p[c], cant+1);
					vistos[i] = false;
				}
			}
		}
	}
	vistos[c] = false;
	
}

int main(){
	int n;
	while (cin>>n && n!=-1){
		//cout<<(int)(n*1.0/M_E + 0.5)<<'\n';
		//continue;
		
		vector<ll> palos(n+2, 0);
		vector<bool> vistos(n+2, false);
		vistos[0] = true;
		//vistos[n+1] = true;
		if (n == 1){
			cin>>n;
			cout<<1<<'\n';
			continue;
		}
		for (int i=0; i<n; ++i){
			cin>>palos[i+1];
		}
		sort(palos.begin(), palos.end());
		carpas = 0;
		int ant = -1;
		for (int i=1; i<palos.size()-1; ++i){
			if (palos[i] != ant){
				ant = palos[i];
				bt(palos, vistos, i, 0, 0);
			}
		}
		cout<<carpas<<'\n';
	}
}
