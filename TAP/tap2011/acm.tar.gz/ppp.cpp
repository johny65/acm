#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

int main(){
	int n=30;
	cout<<n<<'\n';
	for (int i=1; i<=n; ++i)
		cout<<i<<" ";
	cout<<'\n';
	return 0;
}
