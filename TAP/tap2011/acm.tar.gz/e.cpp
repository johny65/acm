#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

long long tipomedia(vector<long long> &v){
	long long m = 0;
	for (long long i=0; i<v.size(); ++i)
		m += v[i];
	return m;
}

long long media(long long tm, long long nuevo, long long cant){
	long long m = (tm+nuevo)/cant;
}

void magia(vector<long long> v, int n, long long casimedia)
{
	int c = 0;
	long long m1 = v[(v.size()-1)/2], m2 = v[(v.size()-1)/2+1];
	cerr<<"m1: "<<m1<<'\n';
	cerr<<"caismedia: "<<casimedia<<'\n';
	cerr<<"m2: "<<m2<<'\n';	
	if (casimedia % (n-1) == 0){
		long long cand = casimedia/(n-1);
		cerr<<cand<<'\n';
		if (cand > m1 && cand < m2)
			c++;
	}
	long long c1 = m1*n-casimedia, c2 = m2*n-casimedia;
	if (c1 < m1){
		cerr<<c1<<'\n';
		if (!binary_search(v.begin(), v.end(), c1))
			c++;
	}
	if (c2 > m2){
		cerr<<c2<<'\n';
		if (!binary_search(v.begin(), v.end(), c2))
			c++;
	}
	
	cout<<c<<'\n';
	
	
}

int main(){
	long long n, t;
	cin>>n;
	while (n != -1){
		vector<long long> v(n-1);
		for (int i=0; i<n-1; ++i){
			cin>>t;
			v[i] = t;
		}
		sort(v.begin(), v.end());
		long long casimedia = tipomedia(v);
		magia(v, n, casimedia);
		cin>>n;
	}
}
