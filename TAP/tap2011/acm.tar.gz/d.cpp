#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

void hobby(vector<unsigned long long> &v, int mini)
{
	unsigned long long todo = 0;
	for (int i=0; i<v.size(); ++i)
		v[i] *= mini;
	
	
	for (int i=0; i<v.size(); ++i){
		todo += v[i] * (v.size()-i);
		
		
		//
		//for (int j=0; j<=i; ++j){
			//if (temps[j] != 0){
				//todo += temps[j] + min*v[j];
			//todo += min*v[j];
			//temps[i] = todo;
			//
		//}
	}
	cout<<todo<<'\n';
}

int main(){
	int temp, min;
	cin>>temp>>min;
	while (temp != -1 && min != -1){
		vector<unsigned long long> v(temp);
		//unsigned long long todo = 0;
		for (int i=0; i<temp; ++i){
			cin>>v[i];
		}
		hobby(v, min);
		cin>>temp>>min;

	}

}
