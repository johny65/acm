#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

class Arbol;

struct nodo{
	nodo(){}
	nodo(int padre):parent(padre){
		profundidad = 0;
	}
	int profundidad, parent;
	vector<int> hijos;
	void edipo(int nuevo, nodo &el, vector<nodo> &tree){
		//cerr << "donde estan mis hijos " << hijos.size() <<endl;
		//for(int K=0; K<hijos.size(); ++K)
			//cerr << hijos[K] << ' ' ;
		//cerr << endl;
		parent = nuevo;
		vector<int>::iterator it = find(hijos.begin(), hijos.end(), nuevo);
		//if(it == hijos.end() ){
			//cerr << "no esta" << endl;
		//}
		hijos.erase(it);
		//recalcular profundidad
//cerr << "recalcular profundidad" << endl;
		int maxi=-1, imaxi=-1, nomaxi=0, inomaxi=0;
		for(int K=0;K<hijos.size(); ++K){
			if( tree[hijos[K]].profundidad > maxi ){
				//cerr << K << ' ' << tree[hijos[K]].profundidad << endl;
				maxi = tree[hijos[K]].profundidad;
			}	
		}
		profundidad = maxi+1;
	}
	void addhijo(int nuevo, nodo &el, vector<nodo> &tree){
		parent = -1;
		hijos.push_back(nuevo);
		if(profundidad < el.profundidad +1)
			profundidad = el.profundidad+1;
	}
};

struct Arbol{
	vector<nodo> tree;
	int root;
	void init(int n){
		tree.clear();
		tree.reserve(n);
		tree.push_back(nodo(-1));
		root=0;
	}
	void addnodo(int index, int parent);
	int profundidad(){
		return tree[root].profundidad;
	}
	//void print(){
		//cerr << "p " ;
		//for(int K=0; K<tree.size(); ++K){
			//cerr << tree[K].profundidad << ' ';
		//}
		//cerr << endl;
	//}
};

Arbol arbol;




int main(){
	int n;
	while(cin>>n and n!=-1){
		arbol.init(n);
		
		for(int K=1; K<n;++K){
			int parent;	
			cin>>parent;
			parent--;
			
			arbol.addnodo(K,parent);
			//arbol.print();
		}
//cerr << "solucion " ;
		cout << arbol.profundidad() << endl;
	}
}

void Arbol::addnodo(int index, int parent){
	tree.push_back(nodo(parent));
	tree[parent].hijos.push_back(index);

//print();
	
	//actualizar las profundidades 
	int yo = index, next;
	bool rebalanceo = true;
	for(next = tree[yo].parent;
		(next != -1);
		next = tree[next].parent){
		if( tree[next].profundidad < tree[yo].profundidad+1 ){
			tree[next].profundidad = tree[yo].profundidad+1;
			yo = next;
		}
		else{
			rebalanceo=false;
			break;
		}
	}
//print();
	if(next != -1) return;
	//cerr << "balanceando";
	//rebalancear el arbolito
	//se busca si la mayor profundidad lleva una distancia de 2
	int maxi=-1, imaxi=-1, nomaxi=0, inomaxi=0;
	vector<int> &hijo = tree[root].hijos;
	for(int K=0;K<hijo.size(); ++K){
		if( tree[hijo[K]].profundidad > maxi ){
		//	nomaxi=maxi;
		//	inomaxi=imaxi;
			maxi = tree[hijo[K]].profundidad;
			imaxi = hijo[K];
		} 
		//else if(tree[hijo[K]].profundidad > nomaxi){
		//	nomaxi = tree[hijo[K]].profundidad;
		//	inomaxi = K;
		//}
	}
	
	
	//if(maxi - nomaxi < 2) return;
	
	//rebalancear (siempre)
	int oldroot = root;
	root = imaxi;
	
//cerr << "max " << maxi  <<' ' <<imaxi<<endl;

	tree[oldroot].edipo(imaxi, tree[imaxi], tree);
	tree[root].addhijo(oldroot, tree[oldroot], tree);
}
