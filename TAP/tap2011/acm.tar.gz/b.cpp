#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

string toggle(string a, string b){
	string c = a;
	for(int K=0; K<a.size(); ++K){
		if(a[K]==b[K])
			c[K]='*';
		else 
			c[K]='.';
	}
	cerr << c << endl;
	return c;
}

int contar(string s){
	int cuenta = 0;
	int buscar = 1;
	for(int K=0; K<s.size(); ++K){
		if(s[K] == '.'){
			cuenta++;
			for(; K<s.size(); ++K)
				if(s[K]=='*')
					break;
		}
	}
	return cuenta;
}

int main(){
	string a,b;
	while(cin>>a>>b and not(a=="*" and b=="*") ){
		string c = toggle(a,b);
		cout << contar(c) << endl;
	}

}
