#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <iomanip>
#include <utility>
#include <limits>

using namespace std;

class punto {
public:
	double x, y;
};

class nodo {
	public:
	bool esta;
	double peso;
	punto pos;
	double f;
	vector< pair<nodo*, double> > ad;
	nodo(){
		esta = true;
		peso = 1e42;
	}
};

typedef pair<nodo*, double> par;

double dijs(vector<nodo> &v, int desde, int hasta){
	
	v[desde].peso = 0;
	
	while (v[hasta].esta){
		double pesominimo = 1e42;
		int minimo = -1;
		for (int i=0; i<v.size(); ++i){
			//if (v[i].peso < 0) continue;
			if (v[i].esta && v[i].peso < pesominimo){
				pesominimo = v[i].peso;
				minimo = i;
			}
		}
		//cerr<<"minimo: "<<minimo<<"peso: "<<pesominimo<<endl;
		v[minimo].esta = false;
		
			//cerr<<v[minimo].ad.size();
		for (int i=0; i<v[minimo].ad.size(); ++i){
			if (v[minimo].ad[i].first->esta){
				
				//if (v[minimo].peso < 0)
					//v[minimo].peso = v[minimo].ad[i].second;
				//else
					v[minimo].ad[i].first->peso = min( v[minimo].ad[i].first->peso, v[minimo].peso + v[minimo].ad[i].second );
					//cerr<<"algo!!!!\n";
				}
		}
	}
	
	return v[hasta].peso;
}

double dist(long long px, long long py, long long lx, long long ly, long long  f){
	double x = px-lx;
	double y = py-ly;
	double res = sqrt(x*x + y*y);
	res -= f;
	return fabs(res);
}

int main(){
	int n;
	long long px, py, lx, ly;
	while (cin>>n>>px>>py>>lx>>ly){
		if (n == -1 && px == -1 && py == -1 && lx == -1 && ly == -1) return 0;
		nodo nuevo;
		vector<nodo> v(n+2, nuevo);
		for (int i=0; i<n; ++i){
			long long cx, cy, f;
			cin>>cx>>cy>>f;
			v[i].pos.x = cx;
			v[i].pos.y = cy;
			v[i].f = f;
		}
		//cerr<<"juju\n";
		v[n].pos.x = px;
		v[n].pos.y = py;
		v[n].f = 0;
		v[n+1].pos.x = lx;
		v[n+1].pos.y = ly;
		v[n+1].f = 0;
		
		par p;
		for (int i=0; i<n+2; ++i){
			for (int j=0; j<n+2; ++j){ //todos contra todos
				p.first = &(v[j]);
				p.second = dist(v[i].pos.x, v[i].pos.y, v[j].pos.x, v[j].pos.y, v[i].f);
				v[i].ad.push_back(p);
			}
		}
		//cerr<<"distancia\n";
		double ddd = dijs(v, n, n+1);
		ddd *= 100; ddd = round(ddd); ddd/=100;
		cout<<setprecision(2)<<fixed<<ddd<<'\n';
	}
	return 0;	

}
